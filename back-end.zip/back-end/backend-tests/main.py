import requests
import json


url = "https://cs6365project.herokuapp.com/getFriendsList"
def test_getFriendsList(steam_id):
    url = f"https://cs6365project.herokuapp.com/getFriendsList?steam_id={steam_id}"
    r = requests.get(url)
    print(r.text)

def local_test():
    steam_api_key = "46A0582A14B15A1C4B377ECC8639676B"
    # from this user: https://steamcommunity.com/id/samninjakiwi
    steam_id = "76561198150719210"
    # Make a request to the Steam Web API to retrieve the friend list
    url = f"https://api.steampowered.com/ISteamUser/GetFriendList/v1/?key={steam_api_key}&steamid={steam_id}"
    data = requests.get(url).json()
    friends_list = [friend["steamid"] for friend in data["friendslist"]["friends"]]
    friends_list_string = ','.join(['"{}"'.format(elem) for elem in friends_list])
    print(friends_list_string)

def test_getGamesList(steam_id):
    url = f"https://cs6365project.herokuapp.com/getGamesList?steam_id={steam_id}"
    r = requests.get(url)
    data = json.loads(r.text)
    games = data['games']
    print(games)
    # app_ids = [game['appid'] for game in games]
    # print(app_ids)

    
    


private_user = "76561198036238119"
public_withfriends_nogames = "76561198150719210"
public_nofriends_withgames = "76561198094705042"
public_withfriends_withgames = "76561198094819444"
steam_ids = [private_user, public_withfriends_nogames, public_nofriends_withgames, public_withfriends_withgames]

# test_getFriendsList(public_withfriends_withgames)
# local_test()
test_getGamesList(public_nofriends_withgames)




