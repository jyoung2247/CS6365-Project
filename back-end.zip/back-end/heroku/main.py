from flask import Flask, jsonify, request
from flask_cors import CORS
import requests
import os
import json
import helper_functions
import steam_recommender

# heroku logs --tail --app cs6365project 
# heroku run bash --app cs6365project

app = Flask(__name__)
CORS(app)
steam_api_key = "46A0582A14B15A1C4B377ECC8639676B"

@app.route('/getFriendsList', methods=['GET'])
def getFriendsList():
    steam_id = request.args.get('steam_id') #Steam ID of the user whose friends you want to retrieve
    print("steam_id:", steam_id)
    try: 
        friends_list = helper_functions.getFriendsList(steam_id)
        return json.dumps({"friends": friends_list}), 200, {"Content-Type": "application/json"}
    except Exception as e:
        print("Error:", e)
        return jsonify({"error": str(e)}), 400

@app.route('/getGamesList', methods=['GET'])
def getGamesList():
    steam_id = request.args.get('steam_id') #Steam ID of the user whose friends you want to retrieve
    try:
        gamesList = helper_functions.getGamesList(steam_id)
        return json.dumps({"games": gamesList}), 200, {"Content-Type": "application/json"}
    except Exception as e:
        print("Error:", e)
        return jsonify({"error": str(e)}), 400

@app.route('/getRMSE', methods=['GET'])
def getRMSE():
    try:
        rmse = steam_recommender.getRMSE()
        return json.dumps({"rmse": rmse}), 200, {"Content-Type": "application/json"}
    except Exception as e:
        print("Error:", e)
        return jsonify({"error": str(e)}), 400

    


    
                

port = int(os.environ.get("PORT", 5000))
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=port)



